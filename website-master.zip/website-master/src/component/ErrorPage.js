import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import Card from '@material-ui/core/Card';
import CardContent from '@material-ui/core/CardContent';
import Typography from '@material-ui/core/Typography';
import Container from '@material-ui/core/Container';

const useStyles = makeStyles({
  page: {
    background: 'rgb(14, 30, 37)',
    position: 'relative',
    display: 'flex',
    height: '100vh',
    width: '100vw',
    alignItems: 'center',
    flexDirection: 'column'
  },
  container: {
    display: 'flex',
    flexDirection: 'column',
    margin: 10 + 'rem'
  },
  card: {
    minWidth: 275,
    padding: 50,
  },
  bullet: {
    display: 'inline-block',
    margin: '0 2px',
    transform: 'scale(0.8)',
  },
  title: {
    fontSize: 14,
  },
  pos: {
    marginBottom: 12,
  },
});

export default function SimpleCard() {
  const classes = useStyles();

  return (
    <div className={classes.page}>
        <Container maxWidth="xs" className={classes.container}>
            <Card className={classes.card}>
                <CardContent>
                    <Typography variant="h5" component="h2">
                    Page Not Found.
                    </Typography>
                    <Typography className={classes.pos} color="textSecondary">
                    404 Error
                    </Typography>
                    <Typography variant="body2" component="p">
                    <br />
                    {"Looks like you've followed a broken link or entered a URL that doesn't exist on this site."}
                    </Typography>
                </CardContent>
            </Card>
        </Container>
    </div>
  );
}
