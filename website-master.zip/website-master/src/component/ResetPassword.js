import React, {useState} from 'react';
import axios from 'axios';
import PropTypes from 'prop-types';
import clsx from 'clsx';
import Avatar from '@material-ui/core/Avatar';
import Button from '@material-ui/core/Button';
import CssBaseline from '@material-ui/core/CssBaseline';
import TextField from '@material-ui/core/TextField';
import LockOutlinedIcon from '@material-ui/icons/LockOutlined';
import FormControl from '@material-ui/core/FormControl';
import FormHelperText from '@material-ui/core/FormHelperText';
import Typography from '@material-ui/core/Typography';
import { makeStyles } from '@material-ui/core/styles';
import Container from '@material-ui/core/Container';
import CloseIcon from '@material-ui/icons/Close';
import { green } from '@material-ui/core/colors';
import IconButton from '@material-ui/core/IconButton';
import ErrorIcon from '@material-ui/icons/Error';
import CheckCircleIcon from '@material-ui/icons/CheckCircle';
import Snackbar from '@material-ui/core/Snackbar';
import SnackbarContent from '@material-ui/core/SnackbarContent';

const variantIcon = {
    success: CheckCircleIcon,
    error: ErrorIcon,
};

const useStyles = makeStyles(theme => ({
    '@global': {
        body: {
            backgroundColor: theme.palette.common.white,
        },
    },
    success: {
        backgroundColor: green[600],
    },
    error: {
        backgroundColor: theme.palette.error.dark,
    },
    icon: {
        fontSize: 20,
    },
    iconVariant: {
        opacity: 0.9,
        marginRight: theme.spacing(1),
    },
    message: {
        display: 'flex',
        alignItems: 'center',
    },
    paper: {
        marginTop: theme.spacing(8),
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
    },
    avatar: {
        margin: theme.spacing(1),
        backgroundColor: theme.palette.secondary.main,
    },
    form: {
        width: '100%', // Fix IE 11 issue.
        marginTop: theme.spacing(1),
    },
    submit: {
        margin: theme.spacing(3, 0, 2),
    },
}));

function MySnackbarContentWrapper(props) {
    const classes = useStyles();
    const { className, message, onClose, variant, ...other } = props;
    const Icon = variantIcon[variant];
    
    return (
      <SnackbarContent
        className={clsx(classes[variant], className)}
        aria-describedby="client-snackbar"
        message={
          <span id="client-snackbar" className={classes.message}>
            <Icon className={clsx(classes.icon, classes.iconVariant)} />
            {message}
          </span>
        }
        action={[
            <IconButton key="close" aria-label="close" color="inherit" onClick={onClose}>
              <CloseIcon className={classes.icon} />
            </IconButton>,
        ]}
        {...other}
      />
    );
}

MySnackbarContentWrapper.propTypes = {
    className: PropTypes.string,
    message: PropTypes.string,
    onClose: PropTypes.func,
    variant: PropTypes.oneOf(['error', 'info', 'success', 'warning']).isRequired,
};

export default function ResetPassowrd(props) {
    const classes = useStyles();
    const [password, setPassword] = useState('');
    const [confirmPassword, setConfirmPassword] = useState('');
    const [isError, handleError] = useState(false);
    const [isDisabled, handleDisabled] = useState(false);
    const token = props.match.params.token;
    const [open, setOpen] = React.useState(false);
    const [variant, setResultStatus] = useState('error');
    const [resultMsg, setResultMessage] = useState('');

    function handleResetPassword(event){
        event.preventDefault();
        if (password === confirmPassword) {            
            handleError(false);
            handleDisabled(true);
                           
            var updateData = {
                password: password
            };
            axios.put('http://138.197.203.178:8080/resetPassword/' + token, updateData).then((res => {
                
                setPassword('');
                setConfirmPassword('');
                handleDisabled(false);  
                if (res.data.error) {
                    //failed
                    console.log(props);
                    setResultStatus('error');
                    setResultMessage(res.data.message);
                } else {
                    //success
                    setResultStatus("success");
                    setResultMessage(res.data.message);
                }                       
                setOpen(true);       
            })).catch(error => {
                console.log(error);
            });
        } else {
            handleError(true);
        }
    }

    function handleClose(event, reason) {
        if (reason === 'clickaway') {
          return;
        }
    
        setOpen(false);
    }

    return (
        <Container component="main" maxWidth="xs">
            <CssBaseline />
            <div className={classes.paper}>
                <Avatar className={classes.avatar}>
                    <LockOutlinedIcon />
                </Avatar>
                <Typography component="h1" variant="h5">
                    Reset Password
                </Typography>
                <Snackbar
                    anchorOrigin={{
                        vertical: 'bottom',
                        horizontal: 'left',
                    }}
                    open={open}
                    autoHideDuration={6000}
                    onClose={handleClose}
                >
                    <MySnackbarContentWrapper
                        variant={variant}
                        message={resultMsg}
                        onClose={handleClose}
                    />
                </Snackbar>
                <form className={classes.form} onSubmit={handleResetPassword}>
                    <FormControl className={classes.formControl} error fullWidth>
                        <TextField
                            variant="outlined"
                            margin="normal"
                            required
                            fullWidth
                            value={password}
                            onChange={e => setPassword(e.target.value)}
                            name="password"
                            label="New Password"
                            type="password"
                            id="password"
                            autoComplete="current-password"
                        />
                    </FormControl>   
                    <FormControl className={classes.formControl} error={isError} fullWidth>                        
                        <TextField
                            variant="outlined"
                            margin="normal"
                            required
                            fullWidth
                            value={confirmPassword}
                            onChange={e => setConfirmPassword(e.target.value)}
                            name="confirmPassword"
                            label="Confirm Password"
                            type="password"
                            id="confirmPassword"
                            autoComplete="current-password"
                            error={isError}
                        />
                        <FormHelperText id="component-error-text" hidden={!isError}>Invalid Confirm Password</FormHelperText>
                    </FormControl>                    
                    <Button
                        type="submit"
                        fullWidth
                        variant="contained"
                        color="primary"
                        disabled={isDisabled}
                        className={classes.submit}
                    >
                        Reset Password
                    </Button>
                </form>
            </div>
        </Container>
    );
}