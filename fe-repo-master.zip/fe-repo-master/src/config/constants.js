// export const SERVER_URL = 'http://localhost:8080';
export const SERVER_URL = 'http://138.197.203.178:8080';
